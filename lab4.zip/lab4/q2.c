#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc, char *argv[])
{
if (argc != 2)
{
fprintf(stderr, "Usage: %s <filename>\n", argv[0]);
return 1;
}
int fd = open(argv[1], O_RDWR);
if (fd == -1)
{
perror("open");
return 1;
}
long file_size = lseek(fd, 0, SEEK_END);
if (file_size == -1) {
perror("lseek");
close(fd);
return 1;
}
char buffer[2];
char temp;
for (long i = 0; i < file_size / 2; i++)
{
lseek(fd, i, SEEK_SET);
if (read(fd, buffer, 1) != 1)
{
perror("read");
close(fd);
return 1;
}
lseek(fd, -i - 1, SEEK_END);
if (read(fd, &temp, 1) != 1)
{
perror("read");
close(fd);
return 1;
}
lseek(fd, i, SEEK_SET);
if (write(fd, &temp, 1) != 1)
{
perror("write");
close(fd);
return 1;
}
lseek(fd, -i - 1, SEEK_END);
if (write(fd, buffer, 1) != 1) {
perror("write");
close(fd);
return 1;
}
}
close(fd);
printf("File content reversed.\n");
return 0;
}