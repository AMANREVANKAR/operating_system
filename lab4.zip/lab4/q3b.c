#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
int main(int argc, char *argv[]) {
if (argc != 3) {
fprintf(stderr, "Usage: %s <filename> <pattern>\n", argv[0]);
return 1;
}
char *filename = argv[1];
char *pattern = argv[2];
// Use fork and exec to call grep command
pid_t pid = fork();
if (pid == -1) {
perror("fork");
return 1;
} else if (pid == 0) {
// Child process: exec grep
execl("/bin/grep", "grep", pattern, filename, NULL);
perror("execl");
_exit(1); // Exit child process if execl fails
} else {
// Parent process: wait for child
int status;
waitpid(pid, &status, 0);
if (WEXITSTATUS(status) != 0) {
fprintf(stderr, "grep exited with error.\n");
return 1;
}
}