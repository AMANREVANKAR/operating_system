#include <stdio.h>
#include <dirent.h>
#include <sys/types.h>
int main() {
DIR *dir;
struct dirent *entry;
dir = opendir("."); // Open the current directory
if (dir == NULL) {
perror("opendir");
return 1;
}
while ((entry = readdir(dir)) != NULL) {
if (entry->d_type == DT_REG) { // Check if it's a regular file
printf("%s\n", entry->d_name);
}
}
closedir(dir);
return 0;
}