
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>
int main()
{
pid_t pid = fork();
if (pid == -1)
{
perror("fork");
exit(EXIT_FAILURE);
}
else if (pid == 0)
{ // Child process
printf("Child process: PID=%d, Parent PID=%d\n", getpid(), getppid());
execl("/bin/ls", "ls", "-l", NULL); // Execute ls command
perror("execl"); // This will only execute if execl fails
exit(EXIT_FAILURE);
}
else
{ // Parent process
printf("Parent process: PID=%d\n", getpid());
wait(NULL); // Wait for the child to finish
printf("Child process finished.\n");
}
int fd = open("example.txt", O_RDONLY);
if (fd == -1) {
perror("open");
return 1;
}
// Check if file opening was successful
if (fd != -1) {
printf("File opened successfully, printing contents:\n");
// Allocate buffer to read file contents
char buffer[BUFSIZ];
// Read the file content loop and print
ssize_t bytes_read;
while ((bytes_read = read(fd, buffer, BUFSIZ)) > 0) {
// Print the read bytes
write(STDOUT_FILENO, buffer, bytes_read);
}
if (bytes_read == -1) {
perror("read");
// You can choose to close the file and return here as well
}
printf("\n");
}
// Close "example.txt"
if (close(fd) == -1) {
perror("close");
return 1;
}
DIR *dir = opendir(".");
if (dir == NULL) {
perror("opendir");
return 1;
}
struct dirent *entry;
while ((entry = readdir(dir)) != NULL) {
struct stat file_stat;
if (stat(entry->d_name, &file_stat) == -1) {
perror("stat");
closedir(dir);
return 1;
}
printf("Name: %s, Size: %ld bytes\n", entry->d_name, file_stat.st_size);
}
closedir(dir);
return 0;
}