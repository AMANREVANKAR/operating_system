
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main() {
// Print initial process ID
printf("Initial process ID: %d\n", getpid());
// a. Create parent & child process and print their IDs
pid_t child_pid = fork();
if (child_pid == -1) {
perror("fork");
exit(1);
} else if (child_pid == 0) {
// Child process
printf("Child process ID: %d\n", getpid());
printf("Parent process ID: %d\n", getppid());
} else {
// Parent process
printf("Parent process ID: %d\n", getpid());
printf("Child process ID: %d\n", child_pid);
}
// b. Create a zombie process
pid_t zombie_pid = fork();
if (zombie_pid == -1) {
perror("fork");
exit(1);
} else if (zombie_pid == 0) {
// Zombie process
printf("Zombie process ID: %d\n", getpid());
exit(0); // Terminate zombie process (optional)
} else {
// Parent process (do not wait for zombie)
// If not waited on, the zombie process is created.
}
// c. Create an orphan process
pid_t orphan_pid = fork();
if (orphan_pid == -1) {
perror("fork");
exit(1);
} else if (orphan_pid == 0) {
// Orphan process
printf("Orphan process ID: %d\n", getpid());
setsid(); // Detach from parent process group
sleep(5); // Orphan process exits after 5 seconds
} else {
// Parent process
printf("Parent process ID: %d\n", getpid());
sleep(1); // Give orphan process time to detach
}
// d. Make the process sleep for a few seconds
printf("Main process sleeping for 3 seconds...\n");
sleep(3);
printf("Main process continuing...\n");
wait(NULL); // Wait for any child processes to terminate
printf("Program finished.\n");
return 0;
}

