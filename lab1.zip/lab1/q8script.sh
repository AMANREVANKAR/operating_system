#!/bin/bash
if [ "$#" -eq 0 ]; then
echo "Error: No filename provided. Please provide
a filename as a command line argument."
exit 1
elif [ "$#" -gt 1 ]; then
echo "Error: Too many arguments. Please provide
only one filename as a command line argument."
exit 1
fi
if [ -f "$1" ]
then
echo "The file exists"
else
echo "The file does not exist"
fi