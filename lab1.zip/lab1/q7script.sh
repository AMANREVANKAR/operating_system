#!/bin/bash
echo "Enter the number"
read number
t=0
while [ $number -gt 0 ]
do
n=$(( $number % 10 ))
t=$(( t + $n ))
number=$((number / 10))
done
echo $t