#!/bin/sh
if [ -z "$1" ]
then
echo "First argument is not provided"
exit
fi
if [ -z "$2" ]
then
echo "Second argument is not provided"
exit
fi
echo "The sum is $(( $1 + $2 ))"