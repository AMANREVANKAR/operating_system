#!/bin/bash
if [ $# -eq 0 ]; then
echo "Usage: $0 <folder_name>"
exit 1
fi
folder_name="$1"
if [ ! -d "$folder_name" ]; then
echo "Error: Folder '$folder_name' not found."
exit 1
fi

their names to a file
find "$folder_name -type d -empty >"
empty_subfolders.txt
echo "Names of empty subfolders in '$folder_name'
saved to 'empty_subfolders.txt'."