#!/bin/bash
echo "Enter the first number:"
read num1
echo "Enter the second number:"
read num2
echo "Enter the operation (+, -, x, /):"
read operation
case $operation in
+)
result=$(echo "$num1 + $num2" | bc)
;;
-)
result=$(echo "$num1 - $num2" | bc)
;;
x)
result=$(echo "$num1 * $num2" | bc)
;;
/)
result=$(echo "scale=2; $num1 / $num2" | bc)
;;
*)
echo "Invalid operation"
exit 1
;;
esac
echo "Result: $result"