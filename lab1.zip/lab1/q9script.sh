#!/bin/bash

argument
if [ "$#" -eq 0 ]; then
echo "Error: No path provided. Please provide a
path as a command line argument."
exit 1
fi

path=$1

if [ ! -d "$path" ]; then
echo "Error: The specified path does not exist."
exit 1
fi

subdirectories_count=$(find "$path" -type d
-mindepth 1 | wc -l)
echo "Number of subdirectories in '$path':
$subdirectories_count"