#!/bin/sh
todaysdate=$(date +"%D")
currenttime=$(date +"%T")
currentdirectory=$(pwd)
echo "The current date is $todaysdate"
echo "The current time is $currenttime"
echo "The username is $USER"
echo "current directory is $currentdirectory"