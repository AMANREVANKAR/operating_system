#!/bin/bash
echo "Enter the number"
read number
t=0
while [ $number -gt 0 ]
do
n=$(( $number % 10 ))
number=$((number / 10))
t=$((t*10 + $n))
done
echo $t