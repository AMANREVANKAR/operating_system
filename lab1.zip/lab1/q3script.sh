#!/bin/sh
if [ -z "$1" ]
then
echo "First argument is not provided"
exit
fi
if [ -z "$2" ]
then
echo "Second argument is not provided"
exit
fi
if [ -z "$3" ]
then
echo "Third argument is not provided"
exit
fi
if [[ "$1" > "$2" ]]
then
if [[ "$1" > "$3" ]]
then
echo "The first number argument is the largest"
else
echo "The third number argument is the largest"
fi
else
if [[ "$2" > "$3" ]]
then
echo "The second number argument is the largest"
else
echo "The third number argument is the largest"
fi
fi