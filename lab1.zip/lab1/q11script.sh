#!/bin/bash
if [ $# -eq 0 ]; then
echo "Usage: $0 <folder_name>"
exit 1
fi
folder_name="$1"
if [ ! -d "$folder_name" ]; then
echo "Error: Folder '$folder_name' not found."
exit 1
fi
# Use find to locate and delete empty subfolders
find "$folder_name" -type d -empty -delete
echo "Empty subfolders in '$folder_name' deleted."