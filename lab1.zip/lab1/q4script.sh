#!/bin/sh
number=5
while [ $number -ge 1 ]
do
echo $number
((number--))
done